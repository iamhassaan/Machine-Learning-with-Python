import numpy as np
from sigmoid import *

def calculate_hypothesis(X, theta, i):
    """
        :param X            : 2D array of our dataset
        :param theta        : 1D array of the trainable parameters
        :param i            : scalar, index of current training sample's row
    """
    hypothesis = 0.0
    # print ("First  {}".format(X[i,0]))
    # print (X[i,1])
    # print (X[i,2])

    #########################################
    # Write your code here
    # You must calculate the hypothesis for the i-th sample of X, given X, theta and i.
    #             hypothesis = X[i, 0] * theta[ 0] + X[i, 1] * theta[1]
    # for x in range(len(theta)):
    #     p=X[i,x]*theta[x]
    #     hypothesis+=p
    hypothesis=np.matmul(X[i],theta.T)  
    # hypothesis= X[i,0] * theta[0] + X[i,1] * theta[1] + X[i,2]*theta[2]
    # print("I am hypo {}".format(hypothesis))
    ########################################/
    # print(hypothesis)
    result = sigmoid(hypothesis)




    return result
